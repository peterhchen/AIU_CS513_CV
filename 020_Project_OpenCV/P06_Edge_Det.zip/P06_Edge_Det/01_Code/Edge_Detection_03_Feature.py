import numpy as np
import cv2

img = cv2.imread('assets/chessboard.png')
img = cv2.resize(img, (0, 0), fx=0.5, fy=0.5)
gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

# https://shimat.github.io/opencvsharp_docs/html/41c8ea2e-f849-77b3-353d-dd65a0316a38.htm
# Good Feature to Track.
# Number corners: 100, min-quality (degree of confidence)= 0.01 (1: best, 0: poor)
# Minimum Eucleadian distance between corners: 10 
corners = cv2.goodFeaturesToTrack(gray, 100, 0.01, 10)
print('corners.shape:', corners.shape)
print('corners:')
print(corners)
# corners.shape: (79, 1, 2)
# corners:
# [[[300. 300.]]
#  [[299. 373.]]
#  ...


cv2.imshow('Frame', img)
cv2.waitKey(0)
cv2.destroyAllWindows()