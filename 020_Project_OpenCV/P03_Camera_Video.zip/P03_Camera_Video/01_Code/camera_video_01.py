import numpy as np
import cv2

cap = cv2.VideoCapture(0) # webcam 0, webcam 1, webcam 2, ... or video file name

while True:
    ret, frame = cap.read()

    cv2.imshow('frame', frame)

    if cv2.waitKey(1) == ord('q'): # wait for 1ms and then check ordinal value of q
        break

cap.release()  # release the camera (to other computer)
cv2.destroyAllWindows()