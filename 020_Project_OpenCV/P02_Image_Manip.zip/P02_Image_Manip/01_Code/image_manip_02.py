import cv2
import random

img = cv2.imread('assets/logo.jpg', -1)

print('cv2.imread => img.shape:', img.shape)
print('type(img):', type(img))
# cv2.imread => img.shape: (182, 276, 3)
# type(img): <class 'numpy.ndarray'>

# Copy part of image
tag = img[10:100, 50:120]  # square 90 x 70 of image copy.9
print('tag.shape:', tag.shape)  # tag.shape: (90, 70, 3)
img[60:150, 0:70] = tag       # (90 x 79 x 3) 
# orignal image size: (182, 276, 3) 
print('img.shape:', img.shape) # orignal image: img.shape: (182, 276, 3)

cv2.imshow('Image', img)
cv2.waitKey(0)
cv2.destroyAllWindows()