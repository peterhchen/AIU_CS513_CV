import cv2
import random

img = cv2.imread('assets/logo.jpg', -1)

print('cv2.imread => img.shape:', img.shape)
print('type(img):', type(img))
# cv2.imread => img.shape: (182, 276, 3)
# type(img): <class 'numpy.ndarray'>
print('img[181][200:202]:')
print(img[181][200:202])
#img[181][200:202]:
#[[244 244 244]
# [244 244 244]]

# Change first 100 rows to random pixels
for i in range(100):
	for j in range(img.shape[1]):
		img[i][j] = [random.randint(0, 255), random.randint(0, 255), random.randint(0, 255)]

cv2.imshow('Image', img)
cv2.waitKey(0)
cv2.destroyAllWindows()